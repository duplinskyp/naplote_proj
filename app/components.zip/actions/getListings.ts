import prisma from "@/app/libs/prismadb";

export interface IListingsParams {
  userId?: string;
  dimensionsX?: number;
  dimensionsY?: number;
  politics?: boolean;
  adultContent?: boolean;
  startDate?: string;
  endDate?: string;
  locationValue?: string;
  category?: string;
}

export default async function getListings(
  params: IListingsParams
) {
  try {
    const {
      userId,
      dimensionsX,
      dimensionsY,
      politics,
      adultContent,
      locationValue,
      startDate,
      endDate,
      category,
    } = params;

    let query: any = {};

    if (userId) {
      query.userId = userId;
    }

    if (category) {
      query.category = category;
    }

    if (dimensionsX) {
      query.dimensionsX = {
        gte: +dimensionsX
      }
    }

    if (dimensionsY) {
      query.dimensionsY = {
        gte: +dimensionsY
      }
    }

    if (locationValue) {
      query.locationValue = locationValue;
    }

    if (politics !== undefined) {
      query.politics = politics;
    }

    if (adultContent !== undefined) {
      query.adultContent = adultContent;
    }

    if (startDate && endDate) {
      query.NOT = {
        reservations: {
          some: {
            OR: [
              {
                endDate: { gte: startDate },
                startDate: { lte: startDate }
              },
              {
                startDate: { lte: endDate },
                endDate: { gte: endDate }
              }
            ]
          }
        }
      }
    }

    const listings = await prisma.listing.findMany({
      where: query,
      orderBy: {
        createdAt: 'desc'
      }
    });

    const safeListings = listings.map((listing) => ({
      ...listing,
      createdAt: listing.createdAt.toISOString(),
      coordinates: listing.coordinates, // Include coordinates in the response
    }));

    console.log('Listings fetched:', safeListings); // Debugging API response

    return safeListings;
  } catch (error: any) {
    throw new Error(error);
  }
}
