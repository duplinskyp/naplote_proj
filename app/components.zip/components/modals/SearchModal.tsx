'use client';

import qs from 'query-string';
import dynamic from 'next/dynamic'
import { useCallback, useMemo, useState } from "react";
import { Range } from 'react-date-range';
import { formatISO } from 'date-fns';
import { useRouter, useSearchParams } from 'next/navigation';

import useSearchModal from "@/app/hooks/useSearchModal";

import Modal from "./Modal";
import Calendar from "../inputs/Calendar";
import Counter from "../inputs/Counter";
import CountrySelect, { 
  CountrySelectValue
} from "../inputs/CountrySelect";
import Heading from '../Heading';
import Input from '../inputs/Input';
import SimpleInput from '../inputs/SimpleInputs';


enum STEPS {
  LOCATION = 0,
  DATE = 1,
  INFO = 2,
}

const SearchModal = () => {

  const [dateRange, setDateRange] = useState({
    startMonth: new Date().getMonth(),
    endMonth: new Date().getMonth() + 1,
  });

  const handleDateChange = (startMonth: number, endMonth: number) => {
    setDateRange({ startMonth, endMonth });
  };


  const router = useRouter();
  const searchModal = useSearchModal();
  const params = useSearchParams();

  const [step, setStep] = useState(STEPS.LOCATION);

  const [location, setLocation] = useState<CountrySelectValue>();
  const [guestCount, setGuestCount] = useState(1);
  const [roomCount, setRoomCount] = useState(1);
  const [bathroomCount, setBathroomCount] = useState(1);
 
  const Map = useMemo(() => dynamic(() => import('../Map'), { 
    ssr: false 
  }), [location]);

  const onBack = useCallback(() => {
    setStep((value) => value - 1);
  }, []);

  const onNext = useCallback(() => {
    setStep((value) => value + 1);
  }, []);

  const onSubmit = useCallback(async () => {
    if (step !== STEPS.INFO) {
      return onNext();
    }

    let currentQuery = {};

    if (params) {
      currentQuery = qs.parse(params.toString())
    }

    const updatedQuery: any = {
      ...currentQuery,
      locationValue: location?.value,
      guestCount,
      roomCount,
      bathroomCount
    };

    if (dateRange.startMonth) {
      updatedQuery.startDate = formatISO(dateRange.startMonth);
    }

    if (dateRange.endMonth) {
      updatedQuery.endDate = formatISO(dateRange.endMonth);
    }

    const url = qs.stringifyUrl({
      url: '/',
      query: updatedQuery,
    }, { skipNull: true });

    setStep(STEPS.LOCATION);
    searchModal.onClose();
    router.push(url);
  }, 
  [
    step, 
    searchModal, 
    location, 
    router, 
    guestCount, 
    roomCount,
    dateRange,
    onNext,
    bathroomCount,
    params
  ]);

  const actionLabel = useMemo(() => {
    if (step === STEPS.INFO) {
      return 'Search'
    }

    return 'Next'
  }, [step]);

  const secondaryActionLabel = useMemo(() => {
    if (step === STEPS.LOCATION) {
      return undefined
    }

    return 'Back'
  }, [step]);

  let bodyContent = (
    <div className="flex flex-col gap-8">
      <Heading
        title="V akej lokalite hľadáte plochu?"
        subtitle="Najdite atraktívnu pozíciu pre vášu reklamu!"
      />
      <CountrySelect 
        value={location} 
        onChange={(value) => 
          setLocation(value as CountrySelectValue)} 
      />
      <hr />
      <Map center={location?.latlng} />
    </div>
  )

  if (step === STEPS.DATE) {
    bodyContent = (
      <div className="flex flex-col gap-8">
        <Heading
          title="Na aké obdobie si chcete plochu prenajať?"
          subtitle="Na mesiac? Alebo iba cez leto? Či na celý rok?"
        />
      <Calendar
        startMonth={dateRange.startMonth}
        endMonth={dateRange.endMonth}
        onChange={handleDateChange}
      />
      </div>
    );
  }
  const [dimensionX, setDimensionX] = useState('');
  const [dimensionY, setDimensionY] = useState('');

  if (step === STEPS.INFO) {
    bodyContent = (
      <div className="flex flex-col gap-8">
        <Heading
          title="Akú veľku plochu hľadáte?"
          subtitle="Chcete nalepiť malý banner? Alebo niekoľko metrový pútač ?"
        />
          <SimpleInput
        id="dimensionsX"
        label="šírka (cm)"
        type="number"
        value={dimensionX}
        onChange={(e) => setDimensionX(e.target.value)}
      />

      <SimpleInput
        id="dimensionsY"
        label="výška (cm)"
        type="number"
        value={dimensionY}
        onChange={(e) => setDimensionY(e.target.value)}
      />
      </div>
    )
  }

  return (
    <Modal
      isOpen={searchModal.isOpen}
      title="Filters"
      actionLabel={actionLabel}
      onSubmit={onSubmit}
      secondaryActionLabel={secondaryActionLabel}
      secondaryAction={step === STEPS.LOCATION ? undefined : onBack}
      onClose={searchModal.onClose}
      body={bodyContent}
    />
  );
}

export default SearchModal;
